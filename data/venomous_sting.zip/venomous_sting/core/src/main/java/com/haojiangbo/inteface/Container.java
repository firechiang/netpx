package com.haojiangbo.inteface;
 /**
  *
 　　* @author 郝江波
 　　* @date 2020/4/15 15:43
 　　*/
public interface Container {
    void start();
    void stop();
}
