package com.haojiangbo.constant;

public class SSLConstant {
    //SSL
    public static final Boolean sslEnabled = true;
    public static final String keystorePath = "C:/netty.keystore";
    public static final String certificatePassword = "123456";
    public static final String keystorePassword = "123456";

}
